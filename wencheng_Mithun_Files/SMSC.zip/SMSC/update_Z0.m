function  Z_0 = update_Z0(Z,D,H,J_0,K,mu)
    view_num = length(Z);

    Z_0 = zeros(size(K));
    for v = 1:view_num
        Z_0 = Z_0 + Z{v} + H{v}/mu - D{v};
    end

    Z_0 = (Z_0 - J_0 - K/mu)*(-1/(v+1));
end