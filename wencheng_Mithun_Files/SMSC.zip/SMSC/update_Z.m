function Z_res = update_Z3(J_0,Z,Z_0,H,D,v,alpha,beta,mu)
    Z_sum = zeros(size(Z_0));
    for i = 1:length(Z)
        Z_sum = Z_sum + Z{i};
    end
    Z_sum = Z_sum - Z{v};
    
    C = beta*(J_0+Z_sum)+mu*(Z_0+H/mu-D);
    
    Z_res = max(0,-(C+alpha)/mu) + min(0,(-C+alpha)/mu);
end