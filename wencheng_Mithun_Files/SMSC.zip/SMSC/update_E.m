function E = update_E(X,D,Y,mu)
    Q = X-X*D+Y/mu;
    alpha = 1/mu;
    
    Q_norm = sqrt(sum(Q.*Q));
    E = repmat((max(0,Q_norm-alpha)./Q_norm),size(X,1),1).*Q;
end