function J_0 = update_J0(Z_0,K,Z,Lap_Matrix,alpha,beta,mu)
    view_num = length(Z);

    Z_sum = zeros(size(K));
    for v = 1:view_num
        Z_sum = Z_sum + Z{v};
    end
    
    J_0 = (mu*(Z_0-K/mu)-beta*Z_sum)/(2*alpha*Lap_Matrix+mu*eye(size(K))+eps);
end