 function J = update_J(J,D,G,mu,alpha)
    M = D + G/mu+eps;
    para = alpha/mu;
    
    [U,S,V] = svd(M);
    H = max(0,S-para) + min(0,S+para);
    
    J = U*H*V';
 end