function [Z,Z_0,D] = SSCWSP(X,alpha,beta,Lap_Matrix,view_num)
    nSample = size(X{1},2);
    Z_0 = zeros(nSample,nSample);
    J_0 = Z_0;
%maxIter =50
%mu = 1e2
%1e6
    maxIter =50;
    mu = 1e3;

    for v = 1:view_num
        E{v} = sparse(size(X{v},1),size(X{v},2));
        D{v} = ones(nSample);
        Z{v} = D{v};
        J{v} = D{v};

        Y{v} = zeros(size(X{v}));
        H{v} = zeros(nSample);
        G{v} = zeros(nSample);
    end
    K = zeros(size(Z_0));

    iter = 0;
    while iter<maxIter
        iter = iter+1;
        %update J_i
        for v = 1:view_num
            J{v} = update_J(J{v},D{v},G{v},mu,alpha);
        end

        %update E_i
        for v = 1:view_num
            E{v} = update_E(X{v},D{v},Y{v},mu);
        end

        %update D_i
        for v = 1:view_num
             D{v} = update_D(X{v},Y{v},E{v},Z{v},Z_0,H{v},G{v},J{v},mu);
        end

        %update Z_i
        for v = 1:view_num
            Z{v} = update_Z(J_0,Z,Z_0,H{v},D{v},v,alpha,beta,mu);
        end

        %update Z_0
        Z_0 = update_Z0(Z,D,H,J_0,K,mu);

        %update J_0
        J_0 = update_J0(Z_0,K,Z,Lap_Matrix,alpha,beta,mu);

        for v = 1:view_num
            Y{v} = Y{v} + mu* (X{v}-X{v}*D{v}-E{v});
            H{v} = H{v} + mu* (Z{v}+Z_0-D{v});
            G{v} = G{v} + mu* (D{v}-J{v});
        end
        K = K + mu*(J_0-Z_0);

        mu = min(1e8,mu*1.2);

        %stop crition
        v_sel = randsrc(1,1,randperm(view_num));
        if norm(J_0-Z_0,'fro')<1e-4 && norm(D{v_sel}-Z_0-Z{v_sel},'fro')<1e-4 && norm(E{v_sel},'fro')<1e-4
            break;
        end
    end
end
