function D = update_D(X,Y,E,Z,Z_0,H,G,J,mu)
    xtx = X'*X;
    D = (xtx+2*eye(size(X,2))+eps)\(xtx+X'*(Y/mu-E)+Z+Z_0+H/mu+J-G/mu);
end