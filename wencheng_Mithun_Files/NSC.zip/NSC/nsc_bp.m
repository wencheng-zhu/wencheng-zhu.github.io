function [W, b, obj] = nlrsc_bp(X, H, C, Wo, bo, nL, lambda2)
%% NSC: back-propagation

stepsize = 1e-4;   % learning rate: 1e-4
maxiter = 2;      % max iteration: 50

obj = zeros(maxiter, 1);
[~, N] = size(X);

%% initializing

dW = cell(size(Wo));
db = cell(size(bo));
for i = 1:nL-1
    dW{i} = zeros(size(Wo{i}));
    db{i} = zeros(size(bo{i}));
end

W = Wo;
b = bo;
clear Wo bo;

%% update

h = cell(nL, 1);
dh = cell(nL, 1);
delta = cell(nL, 1);

for iter = 1:maxiter
    idx = randperm(N);
    for i = 1:N
        h{1} = X(:, idx(i));
        for j = 1:nL-1
            [h{j+1}, dh{j+1}] = tanh_act(W{j} * h{j} + b{j});
        end

        delta{nL} = (h{nL}-H * C(:,idx(i))) .* (dh{nL});

        for j = (nL-1):-1:2
            delta{j} = (W{j}' * delta{j+1}) .* (dh{j});
        end

        for j = 1:(nL-1)
            dW{j} = delta{j+1} * h{j}';
            db{j} = delta{j+1};

            W{j} = W{j} - stepsize * (dW{j} + lambda2 * W{j});
            b{j} = b{j} - stepsize * (db{j} + lambda2 * b{j});
        end
    end
    % stepsize = 0.9 * stepsize;
    % objective function
    obj(iter) = com_obj(X, C, W, b, nL, lambda2);

    if (iter > 1) && (abs(obj(iter) - obj(iter-1)) < 1e-2)
        disp(iter);
        return;
    end
end
end

function obj = com_obj(X, C, W, b, nL, lambda2)
%% computing value of objective function

[~, N] = size(X);

H = nsc_fp(X, W, b, nL);
err = H - H*C;
J =sum(sum(err.*err));

r_W = 0;
r_b = 0;
for j = 1:(nL-1)
    r_t = norm(W{j}, 'fro');
    r_W = r_W + r_t * r_t;
    r_t = norm(b{j}, 'fro');
    r_b = r_b + r_t * r_t;
end

obj = 0.5 * J + (0.5 * lambda2) * (r_W + r_b);
end
