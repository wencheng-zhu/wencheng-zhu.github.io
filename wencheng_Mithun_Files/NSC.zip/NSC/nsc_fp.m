function X = nsc_fp(X, W, b, nL)

N = size(X, 2);
for j = 1:nL-1
      X = tanh_act(W{j} * X + b{j}*ones(1, N));
end
