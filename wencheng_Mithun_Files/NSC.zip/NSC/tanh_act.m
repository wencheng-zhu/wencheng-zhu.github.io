function [a, grad] = tanh_act(X)

tanh
a = tanh(X);

if nargout > 1
    grad = (1-a) .* (1+a);
end


% nonsaturate_sigmoid
% [m, n] = size(X);
% a = zeros(m, n);
% for i = 1:m
%     for j = 1:n
%         t_x = X(i, j);
%         if t_x >= 0
%             a(i, j) = do_newton(t_x);
%         else
%             a(i, j) = - do_newton(-t_x);
%         end
%     end
% end

% if nargout > 1
%     grad = 1 ./ (a.^2 + 1);
% end

%ReLu
% a = X.*(X>=0);

% if nargout > 1
%     grad = (X>=0);
% end

%linear
% a = X;
% if nargout > 1
%     grad = ones(size(X));
% end

%sigmoid
% a = 1 ./ (1 + exp(-X));
%
% if nargout > 1
%     grad = a .* (1 - a);
% end
% end

function y = do_newton(x)

y = x;
g_y = y*y*y/3 + y;
while abs(g_y - x) > 1e-6;
    y = (2*y*y*y/3 + x)/(y*y + 1);
    g_y = y*y*y/3 + y;
end

end
