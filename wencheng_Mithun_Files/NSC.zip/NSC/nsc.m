function [ce,nmi] = nsc(para,X,dim_layer,gnd，L)
%% nsc demo
% data is d*N

nL = length(dim_layer);     % number of layers

%% norm to zero mean
n_sam = size(X, 2);
% x_mean = mean(X, 2);
% fea = X - repmat(x_mean, 1, n_sam);

%% initializing
[Wo, bo] = initialize_Weights(dim_layer, 1);

% initialize H
H = nsc_fp(X, Wo, bo, nL);

% initialize C ( by LSR )
xtx = X'*X;
C = (xtx+para.elpson*eye(n_sam))\xtx;


%% nsc
disp('Start Training');

for i = 1:iter_num
    disp(['Iteration:' num2str(i)]);

    % Update W and b
    [W, b, obj] = nsc_bp(X, H, C, Wo, bo, nL, para.lambda2);
    H = nsc_fp(X, W, b, nL);

    % Update C
    hth = H'*H;
    A = hth;
    B = para.lambda1*L;
    D = -hth;
    C = lyap(A,B,D);

end

